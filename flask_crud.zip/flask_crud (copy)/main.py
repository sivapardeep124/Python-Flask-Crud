from flask import *
from flask_mysqldb import MySQL
import alert
app = Flask(__name__)
app.secret_key = 'abc'

app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'test'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)

#Home Page
@app.route('/',methods= ['GET','POST'])
def home():
    if request.method == 'GET':
        con = mysql.connection.cursor()
        con.execute('SELECT * FROM mysql_python')
        data = con.fetchall()
        return render_template('homepage.html',datas = data)

    if request.method == 'POST':
        name = request.form['nam']
        email = request.form['email']
        password = request.form['pass']
        con = mysql.connection.cursor()
        con.execute('INSERT INTO mysql_python (name,email,pass) VALUES (%s,%s,%s)',(name,email,password))
        mysql.connection.commit()
        con.close()
        flash('Added Successfully')
        return redirect(url_for('home'))
@app.route('/edit/<string:id>',methods = ['GET','POST'])
def edit(id):
    con = mysql.connection.cursor()
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        con = mysql.connection.cursor()
        sql = ('UPDATE mysql_python SET name = %s ,email = %s , pass = %s where ID = %s')
        con.execute(sql, [name, email, password, id])
        mysql.connection.commit()
        con.close()
        return redirect(url_for('home'))

    sql = ('SELECT * FROM mysql_python WHERE ID = %s')
    con.execute(sql, [id])
    res = con.fetchone()
    mysql.connection.commit()
    con.close()
    return render_template('editpage.html', datas=res)

@app.route('/delete/<string:id>',methods = ['GET','POST'])
def delete(id):
    con = mysql.connection.cursor()
    sql = ('DELETE FROM mysql_python WHERE ID = %s')
    con.execute(sql,[id])
    mysql.connection.commit()
    con.close()
    return redirect(url_for('home'))




if (__name__ == '__main__'):
    app.run(debug=True,host='0.0.0.0')